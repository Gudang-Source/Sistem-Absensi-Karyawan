<footer id="footer"><!--Footer-->		
		<!-- <div class="footer-widget">
			<div class="container">
				<div class="row">
					<div class="col-sm-3 col-sm-offset-1">
						<div class="single-widget">
							
							<form action="#" class="searchform">
								<input type="text" placeholder="Isikan alamat email anda" /><button style="height:33px" type="submit" class="btn btn-default"><i class="fa fa-arrow-circle-o-right"></i></button>
								<p>Dapatkan update dari <br />website kami di email anda...</p>
							</form>
						</div>
					</div>
					
				</div>
			</div>
		</div> -->
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyleft © 2015.</p>
					<p class="pull-right">Designed by <span>Themeum and Developed by Muhammad Ridho</span></p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->